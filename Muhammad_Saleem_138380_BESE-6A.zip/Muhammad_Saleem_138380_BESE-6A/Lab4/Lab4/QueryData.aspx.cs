﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
//using System.IO.File;
using System.Data.SqlClient;
using System.Configuration;

namespace Lab4
{
    public partial class QueryData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write("<h3>Welcome " + Session["AdminUserName"] + "</h3>");

        }

        protected void showDataButton_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            conn.Open();
            try
            {
                SqlCommand readQuery = new SqlCommand("select * from Admin", conn);
                SqlDataReader myDataReader = readQuery.ExecuteReader();

                if (myDataReader.Read())
                {
                    Response.Write("<h3>Welcome " + Session["AdminUserName"] + "</h3>");

                }
                else
                {
                    Response.Write("Error loading the data, please try again");
                }

            }
            catch (Exception)
            {
                Response.Write("Error loading the data");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.Columns[1].Visible = false;
        }
    }
}