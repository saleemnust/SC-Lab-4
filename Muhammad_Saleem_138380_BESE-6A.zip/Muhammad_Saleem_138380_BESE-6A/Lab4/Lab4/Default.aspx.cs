﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
//using System.IO.File;
using System.Data.SqlClient;  
using System.Configuration;


    namespace Lab4
    {
        public partial class _Default : Page
        {
            protected void Page_Load(object sender, EventArgs e)
            {
             if(IsPostBack)  
                {  
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);  
                    conn.Open();  
                    //string checkuser = "select count(*) from Database1 where fname='"+fname.Text+"'";  
                    //SqlCommand cmd = new SqlCommand(checkuser, conn);  
                    //int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());  
  
                   // if (temp == 1)  
                    //{  
                    //    Response.Write("Student Already Exist");  
                    //}  
  
                    conn.Close();  
                }  
               
            } 
            
            protected void get_fname(object sender, EventArgs e)
            {
                
            }
            protected void submitButton_Click(object sender, EventArgs e)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "insert into Form (fname, lname, email, address, department) values (@fname,@lname, @email,@address, @department)";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@fname", fname.Text);
                cmd.Parameters.AddWithValue("@lname", lname.Text);
                cmd.Parameters.AddWithValue("@email", email.Text);
                cmd.Parameters.AddWithValue("@address", address.Text);
                cmd.Parameters.AddWithValue("@department", dept.Text);
                Response.Write("Your Form has been added successfuly");

            }


        }
    }

