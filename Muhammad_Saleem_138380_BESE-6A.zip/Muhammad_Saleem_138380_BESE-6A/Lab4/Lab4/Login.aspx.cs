﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
//using System.IO.File;
using System.Data.SqlClient;
using System.Configuration;

namespace Lab4
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            conn.Open();
            try
            {
                    SqlCommand insertQuery = new SqlCommand("select name,email,password from Admin where email='" + loginEmail.Text + "'and password='" + loginPassword.Text + "'", conn);
                    SqlDataReader myDataReader = insertQuery.ExecuteReader();
                    
                    if (myDataReader.Read())
                    {
                        Session["AdminUserName"] = myDataReader[0];
                        Response.Write("welcome" + Session["AdminUserName"]);
                        Response.Redirect("~/QueryData.aspx");
                        
                    }
                    else
                    {
                        Response.Write("Invalid eamil or password. Please try again");
                    }

            }
            catch (Exception)
            {
                Response.Write("Invalid eamil or password");
            }
        }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void loginPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}